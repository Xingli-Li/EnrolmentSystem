$(document).ready(function () {
    //independent field
    var satus = $('#live_form input:radio[name=satus]');
    //dependent field wrapper
    var y = $('#live_form select[name="select_yes"]').parent();
    var n = $('#live_form');
    var all = y.add(n);

    satus.change(function () {//when satus changes
        var value = this.value;
        all.addClass('hidden');
        if (value === 'Yes') {
            y.removeClass('hidden');//show the selection for student
        }

    });
});
